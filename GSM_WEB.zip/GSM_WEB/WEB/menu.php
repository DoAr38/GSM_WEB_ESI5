  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="http://217.182.207.237/GSM_WEB/index.php" class="brand-link">
      <img src="http://217.182.207.237/GSM_WEB/dist/img/logo2.png" alt="AdminLTE Logo" class="brand-image img-rounded elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">GSM Web</span>
    </a>
    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="http://217.182.207.237/GSM_WEB/product.php" class="nav-link active">
              <i class="nav-icon far fas fa-cubes"></i>
              <p class="menuParagrapheColor">Produits</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="http://217.182.207.237/GSM_WEB/logbook.php" class="nav-link">
              <i class="nav-icon far fa-list-alt"></i>
              <p class="menuParagrapheColor">Journal</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="http://217.182.207.237/GSM_WEB/input.php" class="nav-link inputBtnColor">
              <i class="fas fa-plus-circle nav-icon"></i>
              <p class="menuParagrapheColor">Entrée</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="http://217.182.207.237/GSM_WEB/output.php" class="nav-link outputBtnColor">
              <i class="fas fa-minus-circle nav-icon"></i>
              <p class="menuParagrapheColor">Sorties</p>
            </a>
          </li>
          <!--<li class="nav-item">
            <a href="cart.php" class="nav-link">
              <i class="fas fa-cart-plus nav-icon"></i>
              <p class="menuParagrapheColor">Paniers</p>
              <span class="right badge badge-danger">En option</span>
            </a>
          </li>
          <li class="nav-item">
            <a href="order.php" class="nav-link">
              <i class="fas fa-truck nav-icon"></i>
              <p class="menuParagrapheColor">Commandes</p>
              <span class="right badge badge-danger">En option</span>
            </a>
          </li>-->
          <li class="nav-item">
            <a href="http://217.182.207.237/GSM_WEB/supplier.php" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p class="menuParagrapheColor">Fournisseurs</p>
            </a>
          </li>
          <!--<li class="nav-item">
            <a href="customer.php" class="nav-link">
              <i class="nav-icon fas fa-hand-holding-usd"></i>
              <p class="menuParagrapheColor">Clients</p>
              <span class="right badge badge-danger">En option</span>
            </a>
          </li>
          <li class="nav-item">
            <a href="project.php" class="nav-link">
              <i class="nav-icon fas fa-folder"></i>
              <p class="menuParagrapheColor">Affaires</p>
              <span class="right badge badge-danger">En option</span>
            </a>
          </li>-->
          <li class="nav-item">
            <a href="http://217.182.207.237/GSM_WEB/graphic.php" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p class="menuParagrapheColor">Graphiques</p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>