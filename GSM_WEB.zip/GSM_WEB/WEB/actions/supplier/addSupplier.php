<form action="" method="POST">
    <div class="modal-body">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Nouveau fournisseur</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-6">
                        <!-- SOCIETE -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fab fa-houzz"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Societe" name="societe">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <!-- SIGLE -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa-barcode"></i>
                                </span> 
                            </div>
                            <input type="text" class="form-control" placeholder="Sigle" name="sigle">
                        </div>
                    </div>
                </div>       
                <!-- WEB -->
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="fas fa-globe"></i>
                        </span>
                    </div>
                    <input type="text" class="form-control" placeholder="Site web" name="web">
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <!-- ADRESSE -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa-map-marked-alt"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Adresse" name="adresse">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <!-- CODE POSTAL -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa-map-marked-alt"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Code postal" name="code">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <!-- VILLE -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa-map-marked-alt"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Ville" name="ville">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <!-- PAYS -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa-map-marked-alt"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Pays" name="pays">
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class="col-sm-4">
                        <!-- NOM -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa-user"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Nom" name="nom">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <!-- PRENOM -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa-user"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Prenom" name="prenom">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <!-- POSTE -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa-address-card"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Poste" name="poste">
                        </div>
                    </div>
                </div>                        
                <div class='row'>
                    <div class="col-sm-6">
                        <!-- TEL1 -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa-phone"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Telephone 1" name="tel1">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <!-- TEL2 -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa-phone"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Telephone 2" name="tel2">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <!-- MAIL -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa-envelope"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Mail" name="mail">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <!-- FAX -->
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fas fa-fax"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Fax" name="fax">
                        </div>
                    </div>
                </div>  
                <div class="modal-body">
                    <button type="submit" class="btn btn-block btn-primary btn-lg" name="valid">Ajouter</button>
                </div>        
            </div>
        </div>
    </div>
</form>

<?php

    if(isset($_POST['valid'])){

        $societe = $_POST['societe'];
        $sigle = $_POST['sigle'];
        $web = $_POST['web'];
        $adresse = $_POST['adresse'];
        $code = $_POST['code'];
        $ville = $_POST['ville'];
        $pays = $_POST['pays'];
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $poste = $_POST['poste'];
        $tel1 = $_POST['tel1'];
        $tel2 = $_POST['tel2'];
        $mail = $_POST['mail'];
        $fax = $_POST['fax'];
    
        AddSupplier($societe, $sigle, $web, $adresse, $code, $ville, $pays, $nom, $prenom, $poste, $tel1, $tel2, $mail, $fax);
    }    
?>