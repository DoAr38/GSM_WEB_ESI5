<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GSM Web | Fournisseurs</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="../../plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="../../plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="../../plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../../plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="../../plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="../../plugins/summernote/summernote-bs4.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- Solti -->
  <link href="../../dist/css/solti.css" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
<div class="wrapper">
<!-- Navbar -->
  <?php include('../../php/GSMLib_Supplier.php'); ?>
  <!-- /.navbar -->
  <!-- Navbar -->
  <?php include('../../navTop.php'); ?>
  <!-- /.navbar -->
  <!-- Menu -->
  <?php include('../../menu.php'); ?>
  <!-- /.Menu -->

    <?php
        $id = $_GET['id'];
        $supplierName = getSupplierName($id);
        $supplierSigle = getSupplierSigle($id);
        $supplierWeb = getSupplierWeb($id);
        $supplierAdresse = getSupplierAdresse($id);
        $supplierCode = getSupplierCode($id);
        $supplierVille = getSupplierVille($id);
        $supplierPays = getSupplierPays($id);
        $mailSupplier = getSupplierMail($id);
        $nomSupplier = getSupplierNom($id);
        $prenomSupplier = getSupplierPrenom($id);
        $posteSupplier = getPosteSupplier($id);
        $tel1Supplier = getTel1Supplier($id);
        $tel2Supplier = getTel2Supplier($id);
    ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row mb-12">
                <div class="col-sm-12">
                    <hr>
                    <h1 class="m-0 text-dark">Societe : <?php echo $supplierName; ?></h1>   
                    <hr>
                    <?php 
                        //Suppression du fournisseur
                        if(isset($_POST['deleteSupplier'])){
                            DeleteSupplier($id);
                        }
                    ?>
                    <div class="row">
                        <div class="col-sm-5">
                            <form action="" method="post">
                                <input type="submit" class='btn btn-block btn-danger' name='deleteSupplier' value='Supprimer'/>
                            </form>
                        </div>
                        <div class="col-sm-2"></div>
                        <div class="col-sm-5">
                            <?php echo ("<a class='btn btn-block btn-primary' href='mailto:$mailSupplier'>Mail</a>"); ?>
                        </div>
                    </div>
                    <br>
                    <div class="position-relative p-3 bg-gray" style="height: 180px">
                      <div class="ribbon-wrapper ribbon-xl">
                        <div class="ribbon bg-primary text-lg">
                          Contact
                        </div>
                      </div>
                      <?php echo ($nomSupplier." ".$prenomSupplier); ?>
                      <br>
                      <?php echo ("Poste : ".$posteSupplier); ?>
                      <br>
                      <?php echo ("Téléphone 1 : ".$tel1Supplier); ?>
                      <br>
                      <?php echo ("Téléphone 2 : ".$tel2Supplier); ?>
                    </div>
                    <?php

                        if(isset($_POST['updateSupplier'])){
                            
                            $societe = $_POST['societe'];
                            $sigle = $_POST['sigle'];
                            $web = $_POST['web'];
                            $adresse = $_POST['adresse'];
                            $code = $_POST['code'];
                            $ville = $_POST['ville'];
                            $pays = $_POST['pays'];
                            $nom = $_POST['nom'];
                            $prenom = $_POST['prenom'];
                            $poste = $_POST['poste'];
                            $tel1 = $_POST['tel1'];
                            $tel2 = $_POST['tel2'];
                            $mail = $_POST['mail'];
                            $fax = $_POST['fax'];

                            UpdateSupplier($societe, $sigle, $web, $adresse, $code, $ville, $pays, $nom, $prenom, $poste, $tel1, $tel2, $mail, $fax, $id);
                        }

                    ?>
                    <form action="" method="POST">
                      <div class="modal-body">
                        <div class="card card-primary">
                          <div class="card-header">
                            <h3 class="card-title">Modification fournisseur</h3>
                          </div>
                          <div class="card-body">
                            <div class="row">
                              <div class="col-sm-6">
                                  <!-- SOCIETE -->
                                  <div class="input-group mb-3">
                                      <div class="input-group-prepend">
                                          <span class="input-group-text">
                                              <i class="fab fa-houzz"></i>
                                          </span>
                                      </div>
                                      <input type="text" class="form-control" placeholder="Societe" name="societe" value='<?php echo($supplierName); ?>'>
                                  </div>
                              </div>
                              <div class="col-sm-6">
                                  <!-- SIGLE -->
                                  <div class="input-group mb-3">
                                      <div class="input-group-prepend">
                                          <span class="input-group-text">
                                              <i class="fas fa-barcode"></i>
                                          </span> 
                                      </div>
                                      <input type="text" class="form-control" placeholder="Sigle" name="sigle" value='<?php echo($supplierSigle); ?>'>
                                  </div>
                              </div>
                            </div>       
                            <!-- WEB -->
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fas fa-globe"></i>
                                    </span>
                                </div>
                                <input type="text" class="form-control" placeholder="Site web" name="web" value='<?php echo($supplierWeb); ?>'>
                            </div>
                            <div class="row">
                              <div class="col-sm-6">
                                  <!-- ADRESSE -->
                                  <div class="input-group mb-3">
                                      <div class="input-group-prepend">
                                          <span class="input-group-text">
                                              <i class="fas fa-map-marked-alt"></i>
                                          </span>
                                      </div>
                                      <input type="text" class="form-control" placeholder="Adresse" name="adresse" value='<?php echo($supplierAdresse); ?>'>
                                  </div>
                              </div>
                              <div class="col-sm-6">
                                <!-- CODE POSTAL -->
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="fas fa-map-marked-alt"></i>
                                        </span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="Code postal" name="code" value='<?php echo($supplierCode); ?>'>
                                </div>
                              </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <!-- VILLE -->
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-map-marked-alt"></i>
                                            </span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Ville" name="ville" value='<?php echo($supplierVille); ?>'>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <!-- PAYS -->
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-map-marked-alt"></i>
                                            </span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Pays" name="pays" value='<?php echo($supplierPays); ?>'>
                                    </div>
                                </div>
                            </div>
                            <div class='row'>
                                <div class="col-sm-4">
                                    <!-- NOM -->
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-user"></i>
                                            </span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Nom" name="nom" value='<?php echo($nomSupplier); ?>'>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <!-- PRENOM -->
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-user"></i>
                                            </span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Prenom" name="prenom" value='<?php echo($prenomSupplier); ?>'>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <!-- POSTE -->
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-address-card"></i>
                                            </span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Poste" name="poste" value='<?php echo($posteSupplier); ?>'>
                                    </div>
                                </div>
                            </div>                        
                            <div class='row'>
                                <div class="col-sm-6">
                                    <!-- TEL1 -->
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-phone"></i>
                                            </span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Telephone 1" name="tel1" value='<?php echo($tel1Supplier); ?>'>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <!-- TEL2 -->
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-phone"></i>
                                            </span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Telephone 2" name="tel2" value='<?php echo($tel2Supplier); ?>'>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <!-- MAIL -->
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-envelope"></i>
                                            </span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Mail" name="mail" value='<?php echo($mailSupplier); ?>'>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <!-- FAX -->
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-fax"></i>
                                            </span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Fax" name="fax">
                                    </div>
                                </div>
                            </div>  
                            <div class="modal-body">
                                <input type="submit" class="btn btn-block btn-primary btn-lg" name="updateSupplier" value="Enregistrer" />
                            </div>        
                          </div>
                        </div>
                      </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <?php include('../../footer.php') ?>  
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="../../plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- SweetAlert2 -->
<script src="../../plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="../../plugins/toastr/toastr.min.js"></script>
<!-- ChartJS -->
<script src="../../plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="../../plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="../../plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="../../plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="../../plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="../../plugins/moment/moment.min.js"></script>
<script src="../../plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="../../plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="../../plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="../../plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../../dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
<!-- DataTables -->
<script src="../../plugins/other/buttons.flash.min.js"></script>
<script src="../../plugins/other/buttons.html5.min.js"></script>
<script src="../../plugins/other/buttons.print.min.js"></script>
<script src=".././plugins/other/dataTables.buttons.min.js"></script>
<script src="../../plugins/other/jszip.min.js"></script>
<script src="../../plugins/other/pdfmake.min.js"></script>
<script src="../../plugins/other/vfs_fonts.js"></script>
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
</body>
</html>
