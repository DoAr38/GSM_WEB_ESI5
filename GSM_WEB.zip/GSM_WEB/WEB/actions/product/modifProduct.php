<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GSM Web | Produits</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="../../plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="../../plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="../../plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../../plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="../../plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="../../plugins/summernote/summernote-bs4.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- Solti -->
  <link href="../../dist/css/solti.css" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
<div class="wrapper">
 <!-- LIB Prpduct -->
 <?php 
  include('../../php/GSMLib_Product.php'); 
?>
  <!-- Navbar -->
  <?php include('../../navTop.php'); ?>
  <!-- /.navbar -->
  <!-- Menu -->
  <?php include('../../menu.php'); ?>
  <!-- /.Menu -->
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row mb-12">
                <div class="col-sm-12">
                    <hr>
                    <h1 class="m-0 text-dark">Modifier un produit</h1>   
                    <hr>
                </div>

                <?php
                  $reference = $_GET['reference'];
                  $product = GetProductByReference($reference);
                ?>

                <div class="col-12">

<form action="" method="post">  

    <div class="modal-body">

        <div class="card card-primary">

            <div class="card-header">

                <h3 class="card-title">Informations produits</h3>

            </div>

            <div class="card-body">

                <div class="input-group mb-3">

                    <div class="input-group-prepend">

                        <span class="input-group-text">

                            <i class="far fa-credit-card"></i>

                        </span>

                    </div>
                    <?php              
                      $famille = $product->get_famille();
                      echo ("<input type='text' class='form-control' placeholder='Famille' name='famille' value='$famille'>")
                     ?>
                    
                </div>

                <div class="input-group mb-3">

                    <div class="input-group-prepend">

                        <span class="input-group-text">

                            <i class="fas fa-barcode"></i>

                        </span>

                    </div>

                    <?php              
                      $reference = $product->get_reference();
                      echo ("<input type='text' class='form-control' placeholder='Référence' name='reference' value='$reference'>")
                    ?>

                </div>

                <div class="input-group mb-3">

                    <div class="input-group-prepend">

                        <span class="input-group-text">

                            <i class="fas fa-pen-square"></i>

                        </span>

                    </div>

                    <?php              
                      $designation = $product->get_designation();
                      echo ("<input type='text' class='form-control' placeholder='Désignation' name='designation' value='$designation'>")
                    ?>

                </div>

                <div class="input-group mb-3">

                    <div class="input-group-prepend">

                        <span class="input-group-text">

                            <i class="fas fas fa-users"></i>

                        </span>

                    </div>
                    
                    <?php              
                      $fournisseur = $product->get_fournisseur();
                      echo ("<input type='text' class='form-control' placeholder='Fournisseur' name='fournisseur' value='$fournisseur'>")
                    ?>
                </div>

                <div class="input-group mb-3">

                    <div class="input-group-prepend">

                        <span class="input-group-text">

                            <i class="fas fa-cubes"></i>

                        </span>

                    </div>

                    <?php              
                      $qte = $product->get_quantite();
                      echo ("<input type='number' class='form-control' placeholder='Quantité' name='qte' value='$qte'>")
                    ?>

                </div>

                <div class="input-group mb-3">

                    <div class="input-group-prepend">

                        <span class="input-group-text">

                            <i class="fas fa-minus-square"></i>

                        </span>

                    </div>

                    <?php              
                      $mini = $product->get_mini();
                      echo ("<input type='number' class='form-control' placeholder='Mini' name='mini' value='$mini'>")
                    ?>

                </div>

                <div class="input-group mb-3">

                    <div class="input-group-prepend">

                        <span class="input-group-text">

                            <i class="fas fa-map-marked-alt"></i>

                        </span>

                    </div>

                    <?php              
                      $emplacement = $product->get_emplacement();
                      echo ("<input type='text' class='form-control' placeholder='Emplacement' name='emplacement' value='$emplacement'>")
                    ?>


                </div>

                <div class="input-group mb-3">

                    <div class="input-group-prepend">

                        <span class="input-group-text">

                            <i class="fas fa-hand-holding-usd"></i>

                        </span>

                    </div>

                    <?php              
                      $pua = $product->get_pua();
                      echo ("<input type='number' class='form-control' placeholder='PUA' name='pua' value='$pua'>")
                    ?>


                </div>

                <div class="input-group mb-3">

                    <div class="input-group-prepend">

                        <span class="input-group-text">

                            <i class="fas fa-hand-holding-usd"></i>

                        </span>

                    </div>


                    <?php              
                      $puv = $product->get_puv();
                      echo ("<input type='number' class='form-control' placeholder='PUV' name='puv' value='$puv'>")
                    ?>

                </div>
                <div class="modal-body">

        <button type="submit" class="btn btn-block btn-primary btn-lg" name="valid">Modifier</button>

    </div>    
            </div>
            
        </div> 

    </div>

</form>

<form action="" method="post">  

    <div class="modal-body">

        <div class="card card-danger">

            <div class="card-header">

                <h3 class="card-title">Suppression produits</h3>

            </div>

            <div class="card-body">

                

                <div class="modal-body">

        <button type="submit" class="btn btn-block btn-danger btn-lg" name="validSuppr">Supprimer</button>

    </div>    
            </div>
            
        </div> 

    </div>

</form>

<?php

        if(isset($_POST['valid'])){

            $famille = $_POST['famille'];

            $reference = $_POST['reference'];

            $designation = $_POST['designation'];

            $fournisseur = $_POST['fournisseur'];

            $qte = $_POST['qte'];

            $mini = $_POST['mini'];

            $emplacement = $_POST['emplacement'];

            $pua = $_POST['pua'];

            $puv = $_POST['puv'];



            $updateProd = new CProduct();

            $updateProd->set_id($product->get_id());
            $updateProd->set_famille($famille);
            $updateProd->set_reference($reference);
            $updateProd->set_designation($designation);
            $updateProd->set_fournisseur($fournisseur);
            $updateProd->set_quantite($qte);
            $updateProd->set_mini($mini);
            $updateProd->set_emplacement($emplacement);
            $updateProd->set_pua($pua);
            $updateProd->set_puv($puv);

            UpdateProductByReference($updateProd);
        }


        if(isset($_POST['validSuppr'])){
            DeleteProductByID($product->get_id());
        }

?>

        </div>

                <div class="col-sm-12">
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <?php include('../../footer.php') ?> 
  </footer>
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="../../plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="../../plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="../../plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="../../plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="../../plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="../../plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="../../plugins/moment/moment.min.js"></script>
<script src="../../plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="../../plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="../../plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="../../plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../../dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
<!-- DataTables -->
<script src="../../plugins/other/buttons.flash.min.js"></script>
<script src="../../plugins/other/buttons.html5.min.js"></script>
<script src="../../plugins/other/buttons.print.min.js"></script>
<script src="../../plugins/other/dataTables.buttons.min.js"></script>
<script src="../../plugins/other/jszip.min.js"></script>
<script src="../../plugins/other/pdfmake.min.js"></script>
<script src="../../plugins/other/vfs_fonts.js"></script>
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
</body>
</html>

