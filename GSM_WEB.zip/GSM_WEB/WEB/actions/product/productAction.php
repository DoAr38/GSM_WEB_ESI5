<?php

    if(isset($_POST['exportButton'])){
        exportoCsv();
    }

?>

<!-- ADD PRODUCT -->

<div class="modal fade" id="modal-add-product">

    <div class="modal-dialog">

        <div class="modal-content">

            <form action="" method="post">  

                <div class="modal-header">

                    <h4 class="modal-title">Ajouter un produit</h4>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                        <span aria-hidden="true">&times;</span>

                    </button>

                </div>

                <div class="modal-body">

                    <div class="card card-primary">

                        <div class="card-header">

                            <h3 class="card-title">Informations produits</h3>

                        </div>

                        <div class="card-body">

                            <div class="input-group mb-3">

                                <div class="input-group-prepend">

                                    <span class="input-group-text">

                                        <i class="far fa-credit-card"></i>

                                    </span>

                                </div>

                                <input type="text" class="form-control" placeholder="Famille" name="famille">

                            </div>

                            <div class="input-group mb-3">

                                <div class="input-group-prepend">

                                    <span class="input-group-text">

                                        <i class="fas fa-barcode"></i>

                                    </span>

                                </div>

                                <input type="text" class="form-control" placeholder="Référence" name="reference">

                            </div>

                            <div class="input-group mb-3">

                                <div class="input-group-prepend">

                                    <span class="input-group-text">

                                        <i class="fas fa-pen-square"></i>

                                    </span>

                                </div>

                                <input type="text" class="form-control" placeholder="Désignation" name="designation">

                            </div>

                            <div class="input-group mb-3">

                                <div class="input-group-prepend">

                                    <span class="input-group-text">

                                        <i class="fas fas fa-users"></i>

                                    </span>

                                </div>

                                <input type="text" class="form-control" placeholder="Fournisseur" name="fournisseur">

                            </div>

                            <div class="input-group mb-3">

                                <div class="input-group-prepend">

                                    <span class="input-group-text">

                                        <i class="fas fa-cubes"></i>

                                    </span>

                                </div>

                                <input type="number" class="form-control" placeholder="Quantité" name="qte">

                            </div>

                            <div class="input-group mb-3">

                                <div class="input-group-prepend">

                                    <span class="input-group-text">

                                        <i class="fas fa-minus-square"></i>

                                    </span>

                                </div>

                                <input type="number" class="form-control" placeholder="Mini" name="mini">

                            </div>

                            <div class="input-group mb-3">

                                <div class="input-group-prepend">

                                    <span class="input-group-text">

                                        <i class="fas fa-map-marked-alt"></i>

                                    </span>

                                </div>

                                <input type="text" class="form-control" placeholder="Emplacement" name="emplacement">

                            </div>

                            <div class="input-group mb-3">

                                <div class="input-group-prepend">

                                    <span class="input-group-text">

                                        <i class="fas fa-hand-holding-usd"></i>

                                    </span>

                                </div>

                                <input type="text" class="form-control" placeholder="PUA" name="pua">

                            </div>

                            <div class="input-group mb-3">

                                <div class="input-group-prepend">

                                    <span class="input-group-text">

                                        <i class="fas fa-hand-holding-usd"></i>

                                    </span>

                                </div>

                                <input type="text" class="form-control" placeholder="PUV" name="puv">

                            </div>

                        </div>

                    </div>

                </div>

                <div class="modal-footer justify-content-between">

                    <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>

                    <input type="submit" class="btn btn-primary" name='validNewProduct' value="Ajouter"/>

                </div>

            </form>

            <?php

                    if(isset($_POST['validNewProduct'])){



                        $echo("OKOKOKOKOOKKKOO");



                        /*$famille = $_POST['famille'];

                        $reference = $_POST['reference'];

                        $designation = $_POST['designation'];

                        $fournisseur = $_POST['fournisseur'];

                        $qte = $_POST['qte'];

                        $mini = $_POST['mini'];

                        $emplacement = $_POST['emplacement'];

                        $pua = $_POST['pua'];

                        $puv = $_POST['puv'];



                        NewProduct($famille, $reference, $designation, $fournisseur, $qte, $mini, $emplacement, $pua, $puv);*/



                    }

                ?>

        </div>

    </div>

</div>

<!-- ./ADD PRODUCT -->

<!-- EXPORT PRODUCT -->

<div class="modal fade" id="modal-export-product">

    <div class="modal-dialog">

        <div class="modal-content">

            <div class="modal-header">

                <h4 class="modal-title">Exporter les produits</h4>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                    <span aria-hidden="true">&times;</span>

                </button>

            </div>

            <div class="modal-body">

                <button type="button" class="btn btn-block btn-primary btn-lg">Format CSV</button>

            </div>

            <div class="modal-footer justify-content-between">

                <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>

            </div>

        </div>

    </div>

</div>

<!-- ./EXPORT PRODUCT -->