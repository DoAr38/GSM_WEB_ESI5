<div class="card card-primary">
    <div class="card-header productBtnColor">
        <h3 class="card-title">Actions</h3>
        <div class="card-tools">
        <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
        <i class="fas fa-minus"></i></button>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <button type="button" class="btn btn-app" data-toggle="modal" data-target="#modal-export-logbook">
                <i class="fas fa-file-export"></i> Exporter
            </button>
        </div>
    </div>
</div>
<!-- EXPORT PRODUCT -->
<div class="modal fade" id="modal-export-logbook">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Exporter le journal</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <button type="button" class="btn btn-block btn-primary btn-lg">Format CSV</button>
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
            </div>
        </div>
    </div>
</div>
<!-- ./EXPORT PRODUCT -->