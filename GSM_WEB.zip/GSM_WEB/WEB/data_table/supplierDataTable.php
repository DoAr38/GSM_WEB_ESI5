    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header productBtnColor">
              <h3 class="card-title menuParagrapheColor">Liste des fournisseurs</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="tableSupplier" class="table table-bordered table-striped">
                <thead>
                    <tr>
                    <th>Societe</th>
                    <th>Mail</th>
                    <th>Web</th>
                    <th>Sigle</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                      DisplaySupplier();
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                    <th>Societe</th>
                    <th>Mail</th>
                    <th>Web</th>               
                    <th>Sigle</th>
                    </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->