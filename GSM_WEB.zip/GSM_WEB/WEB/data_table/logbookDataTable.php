    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header productBtnColor">
              <h3 class="card-title menuParagrapheColor">Historique des mouvements</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Dates</th>
                  <th>Type</th>
                  <th>Reference</th>
                  <th>Designation</th>
                  <th>Mouvement</th>
                </tr>
                </thead>
                <tbody>
                  <?php 
                    DisplayLogbook();
                  ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Dates</th>
                  <th>Type</th>
                  <th>Reference</th>
                  <th>Designation</th>
                  <th>Mouvement</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->