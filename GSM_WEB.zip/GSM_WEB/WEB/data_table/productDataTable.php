    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header productBtnColor">
              <h3 class="card-title menuParagrapheColor">Listes des produits</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="tableProduct" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Famille</th>
                  <th>Reference</th>
                  <th>Designation</th>
                  <th>Quantite</th>
                  <th>Emplacement</th>
                  <th>PUA</th>
                  <th>PUV</th>
                </tr>
                </thead>
                <tbody>
                  <?php 
                    DisplayProduct();
                  ?>
                </tbody>
                <tfoot>
                <tr>
                <th>Famille</th>
                  <th>Reference</th>
                  <th>Designation</th>
                  <th>Quantite</th>
                  <th>Emplacement</th>
                  <th>PUA</th>
                  <th>PUV</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->