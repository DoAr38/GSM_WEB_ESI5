<?php

include("GSMLib.php");

//////////////////////////////////////////////////////FOURNISSEUR/////////////////////////////////////////////////

//Afficher tous les fournisseurs
function DisplaySupplier(){

    $bdd = Connection();



    $res = "";



    foreach($bdd->query("SELECT * FROM t_fournisseurs") as $data){

        echo "<tr>";

        echo "<td><a class='btn btn-block btn-default' href='http://217.182.207.237/GSM_WEB/actions/supplier/modifSupplier.php?id=".$data['id']."'>".$data['Societe']."</a></td>";

        echo "<td><a href='mailto:".$data['Mail']."'>".$data['Mail']."</a></td>";

        echo "<td><a href='http://".$data['Web']."' target='_blank'>".$data['Web']."</a></td>";

        echo "<td>".$data['Sigle']."</td>";

        echo "</tr>";

    }

}
//Ajouter un fournisseur
function AddSupplier($societe, $sigle, $web, $adresse, $code, $ville, $pays, $nom, $prenom, $poste, $tel1, $tel2, $mail, $fax){



    $bdd = Connection();



    $res= "";



    $reqInsert = "INSERT INTO t_fournisseurs (Societe, Sigle, Web, Adresse, Code, Ville, Pays, Nom, Prenom, Poste, Tel1, Tel2, Mail, Fax) VALUES (";

    $reqInsert = $reqInsert."'$societe', '$sigle', '$web', '$adresse', '$code', '$ville', '$pays', '$nom', '$prenom', '$poste', '$tel1', '$tel2', '$mail', '$fax')";



    $bdd->query($reqInsert);



    $res = "<div class='alert alert-success alert-dismissible'>

                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>

                    <h5><i class='icon fas fa-check'></i> Fournisseur enregistrée !</h5>      

            </div>";

    echo($res);

}
//Supprime un fournisseur
function DeleteSupplier($id){

    $bdd = Connection();



    $res = "";



    $req = "DELETE FROM t_fournisseurs WHERE id = ".$id."";



    $bdd->query($req);



    $res = "<div class='alert alert-success alert-dismissible'>

                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>

                    <h5><i class='icon fas fa-check'></i> Fournisseur supprimé !</h5>      

            </div>";



    echo ($res);



    sleep(3);



    header("Location: http://217.182.207.237/GSM_WEB/supplier.php");



    exit;

}

//Met à jour un fournisseur
function UpdateSupplier($societe, $sigle, $web, $adresse, $code, $ville, $pays, $nom, $prenom, $poste, $tel1, $tel2, $mail, $fax, $id){
    $bdd = Connection();
    $res= "";

    $reqUpdate = "UPDATE t_fournisseurs SET Societe = '$societe', ";
    $reqUpdate = $reqUpdate."Sigle = '$sigle', ";
    $reqUpdate = $reqUpdate."Web = '$web', ";
    $reqUpdate = $reqUpdate."Adresse = '$adresse', ";
    $reqUpdate = $reqUpdate."Code = '$code', ";
    $reqUpdate = $reqUpdate."Ville = '$ville', ";
    $reqUpdate = $reqUpdate."Pays = '$pays', ";
    $reqUpdate = $reqUpdate."Nom = '$nom', ";
    $reqUpdate = $reqUpdate."Prenom = '$prenom', ";
    $reqUpdate = $reqUpdate."Poste = '$poste', ";
    $reqUpdate = $reqUpdate."Tel1 = '$tel1', ";
    $reqUpdate = $reqUpdate."Tel2 = '$tel2', ";
    $reqUpdate = $reqUpdate."Mail = '$mail', ";
    $reqUpdate = $reqUpdate."Fax = '$fax'";
    $reqUpdate = $reqUpdate." WHERE ID = ".$id."";

    $bdd->query($reqUpdate);


    $res = "<div class='alert alert-success alert-dismissible'>

                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>

                    <h5><i class='icon fas fa-check'></i> Fournisseur modifié !</h5>      

            </div>";

    echo($res);
}

//Nom du fournisseur
function getSupplierName($id){

    $bdd = Connection();



    $req = "SELECT Societe FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Societe'];

    }



    return $result;

}
//Sigle du fournisseur
function getSupplierSigle($id){

    $bdd = Connection();



    $req = "SELECT Sigle FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Sigle'];

    }



    return $result;

}
//Web du fournisseur
function getSupplierWeb($id){

    $bdd = Connection();



    $req = "SELECT Web FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Web'];

    }



    return $result;

}
//Adresse du fournisseur
function getSupplierAdresse($id){

    $bdd = Connection();



    $req = "SELECT Adresse FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Adresse'];

    }



    return $result;

}
//Code postal du fournisseur
function getSupplierCode($id){

    $bdd = Connection();



    $req = "SELECT Code FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Code'];

    }



    return $result;

}
//Ville du fournisseur
function getSupplierVille($id){

    $bdd = Connection();



    $req = "SELECT Ville FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Ville'];

    }



    return $result;

}
//Pays du fournisseur
function getSupplierPays($id){

    $bdd = Connection();



    $req = "SELECT Pays FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Pays'];

    }



    return $result;

}
//Mail du fournisseur
function getSupplierMail($id){

    $bdd = Connection();



    $req = "SELECT Mail FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Mail'];

    }



    return $result;

}
//Nom du fournisseur
function getSupplierNom($id){

    $bdd = Connection();



    $req = "SELECT Nom FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Nom'];

    }



    return $result;

}
//Prenom du fournisseur
function getSupplierPrenom($id){

    $bdd = Connection();



    $req = "SELECT Prenom FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Prenom'];

    }



    return $result;

}
//Poste du fournisseur
function getPosteSupplier($id){

    $bdd = Connection();



    $req = "SELECT Poste FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Poste'];

    }



    return $result;

}
//Tel1 du fournisseur
function getTel1Supplier($id){

    $bdd = Connection();



    $req = "SELECT Tel1 FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Tel1'];

    }



    return $result;

}
//Tel2 du fournisseur
function getTel2Supplier($id){

    $bdd = Connection();



    $req = "SELECT Tel2 FROM t_fournisseurs WHERE id = ".$id."";



    $result = "";



    foreach($bdd->query($req) as $data){

        $result = $data['Tel2'];

    }



    return $result;

}

//Liste déroulante fournisseur
function DisplayComboSupplier(){

    $bdd = Connection();

    foreach($bdd->query("SELECT Societe FROM t_fournisseurs") as $data){

        echo "<option value='".$data['Societe']."'>".$data['Societe']."</option>";

    }

}
//////////////////////////////////////////////////////FOURNISSEUR/////////////////////////////////////////////////

?>