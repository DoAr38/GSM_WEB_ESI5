<?php

include("GSMLib.php");

//////////////////////////////////////////////////////JOURNAL/////////////////////////////////////////////////

//Afficher le journal
function DisplayLogbook(){

    $bdd = Connection();

    $res = "";

    foreach($bdd->query("SELECT * FROM t_journal") as $data){
        echo "<tr>";
        echo "<td>".$data['Dates']."</td>";
        echo "<td>".$data['Type']."</td>";
        echo "<td>".$data['Reference']."</td>";
        echo "<td>".$data['Designation']."</td>";
        echo "<td>".$data['Mouvement']."</td>";
        echo "</tr>";
    }
}

//////////////////////////////////////////////////////JOURNAL/////////////////////////////////////////////////

?>



