<?php

include("GSMLib.php");

//////////////////////////////////////////////////////PRODUIT/////////////////////////////////////////////////

//Afficher tous les fournisseurs
function DisplayProduct(){

    $bdd = Connection();

    $res = "";

    foreach($bdd->query("SELECT * FROM t_produits") as $data){
        echo "<tr>";
        echo "<td>".$data['Famille']."</td>";
        echo "<td><a href='http://217.182.207.237/GSM_WEB/actions/product/modifProduct.php?reference=".$data['Reference']."'>".$data['Reference']."</a></td>";
        echo "<td>".$data['Designation']."</td>";
        echo "<td>".$data['Quantite']."</td>";
        echo "<td>".$data['Emplacement']."</td>";
        echo "<td>".$data['PUA']."</td>";
        echo "<td>".$data['PUV']."</td>";
        echo "</tr>";
    }
}

function NewProduct($famille, $reference, $designation, $fournisseur, $qte, $mini, $emplacement, $pua, $puv){

    $bdd = Connection();

    $pta = $pua * $qte;
    $ptv = $puv * $qte;

    $reqNewProduct = "INSERT INTO t_produits (Famille, Reference, Designation, Fournisseur, Quantite, Mini, Emplacement, PUA, PTA, PUV, PTV)";
    $reqNewProduct =$reqNewProduct." VALUES ('$famille','$reference','$designation','$fournisseur',$qte,$mini,'$emplacement',$pua,$pta,$puv,$ptv)";
    $bdd->query($reqNewProduct);

    header('Location: http://217.182.207.237/GSM_WEB/product.php');
    exit;
}

function GetProductByReference($reference){
    $bdd = Connection();

    $product = new CProduct();

    foreach($bdd->query("SELECT * FROM t_produits WHERE Reference = '$reference'") as $data){
        $product->set_id($data['id']);
        $product->set_famille($data['Famille']);
        $product->set_reference($data['Reference']);
        $product->set_designation($data['Designation']);
        $product->set_fournisseur($data['Fournisseur']);
        $product->set_quantite($data['Quantite']);
        $product->set_mini($data['Mini']);
        $product->set_emplacement($data['Emplacement']);
        $product->set_pua($data['PUA']);
        $product->set_pta($data['PTA']);
        $product->set_puv($data['PUV']);
        $product->set_ptv($data['PTV']);
    }

    return $product;
}

function UpdateProductByReference($product){

    $bdd = Connection();

    $id = $product->get_id();
    $famille = $product->get_famille();
    $reference = $product->get_reference();
    $designation = $product->get_designation();
    $fournisseur = $product->get_fournisseur();
    $qte = $product->get_quantite();
    $mini = $product->get_mini();
    $emplacement = $product->get_emplacement();
    $pua = $product->get_pua();
    $puv = $product->get_puv();

    $pta = $qte * $pua;
    $ptv = $qte * $puv;

    $reqUpdate = "UPDATE t_produits SET Famille = '$famille', ";
    $reqUpdate = $reqUpdate."Reference = '$reference', ";
    $reqUpdate = $reqUpdate."Designation = '$designation', ";
    $reqUpdate = $reqUpdate."Fournisseur = '$fournisseur', ";
    $reqUpdate = $reqUpdate."Quantite = $qte, ";
    $reqUpdate = $reqUpdate."Mini = $mini, ";
    $reqUpdate = $reqUpdate."Emplacement = '$emplacement', ";
    $reqUpdate = $reqUpdate."PUA = $pua, ";
    $reqUpdate = $reqUpdate."PTA = $pta, ";
    $reqUpdate = $reqUpdate."PUV = $puv, ";
    $reqUpdate = $reqUpdate."PTV = $ptv ";
    $reqUpdate = $reqUpdate."WHERE id = $id";
    
    $bdd->query($reqUpdate);
}

function DeleteProductByID($id){
    $bdd = Connection();

    $reqDelete = "DELETE FROM t_produits WHERE ID = ".$id;
    
    $bdd->query($reqDelete);
}

function exportoCsv(){
    echo ("OKOKOKOK");
    /*$bdd = Connection();

    $sql = "SELECT * FROM t_produits";

    $statement = $pdo->prepare($sql);

    $statement->execute();

    $rows = $statement->fetchAll(PDO::FETCH_ASSOC);

    $columnNames = array();
    if(!empty($rows)){
        $firstRow = $rows[0];
        foreach($firstRow as $colName => $val){
            $columnNames[] = $colName;
        }
    }

    $fileName = "produits.csv";

    header('Content-Type: application/excel');
    header('Content-Disposition: attachment; filename="' . $fileName . '"');
    
    $fp = fopen('C:\Users\laure\Downloads', 'w');

    fputcsv($fp, $columnNames);

    foreach ($rows as $row) {
        fputcsv($fp, $row);
    }
    fclose($fp);*/
}

function RemoveQty($reference, $qty, $comment){
    $bdd = Connection();
    $sql = "UPDATE t_produits SET Quantite = Quantite - $qty WHERE Reference = '$reference'";
    $bdd->query($sql);

    $product = GetProductByReference($reference);

    $famille = $product->get_famille();
    $idProd = $product->get_id();
    $designation = $product->get_designation();
    $fournisseur = $product->get_fournisseur();
    $qte = $product->get_quantite();
    $mini = $product->get_mini();
    $emplacement = $product->get_emplacement();

    $dates = date("Y-m-d H:i:s");
    $pua = $product->get_pua();
    $puv = $product->get_puv();
    $pta = $pua * $qty;
    $ptv = $puv * $qty;

    $sqlLogbook = "INSERT INTO t_journal (Dates, `Type`, Commentaire, Famille, ID_Prod, Reference, Designation, Fournisseur, Quantite, Mouvement, Mini, Emplacement, PUA, PTA, PUV, PTV, Utilisateur)";
    $sqlLogbook = $sqlLogbook."VALUES ('$dates', 'Sortie', '$comment', '$famille', $idProd, '$reference', '$designation', '$fournisseur',";
    $sqlLogbook = $sqlLogbook."$qte, $qty, $mini, '$emplacement', $pua, $pta, $puv, $ptv, 'User')";

    $bdd->query($sqlLogbook);

    $data = $dates."£".$reference."£".$designation."£".$qty."£Sortie";
    $sqlTemp = "INSERT INTO t_temp (`Data`) VALUES ('$data')";
    $bdd->query($sqlTemp);
}

function AddQty($reference, $qty, $comment){
    $bdd = Connection();
    $sql = "UPDATE t_produits SET Quantite = Quantite + $qty WHERE Reference = '$reference'";
    $bdd->query($sql);

    $product = GetProductByReference($reference);

    $famille = $product->get_famille();
    $idProd = $product->get_id();
    $designation = $product->get_designation();
    $fournisseur = $product->get_fournisseur();
    $qte = $product->get_quantite();
    $mini = $product->get_mini();
    $emplacement = $product->get_emplacement();

    $dates = date("Y-m-d H:i:s");
    $pua = $product->get_pua();
    $puv = $product->get_puv();
    $pta = $pua * $qty;
    $ptv = $puv * $qty;

    $sqlLogbook = "INSERT INTO t_journal (Dates, `Type`, Commentaire, Famille, ID_Prod, Reference, Designation, Fournisseur, Quantite, Mouvement, Mini, Emplacement, PUA, PTA, PUV, PTV, Utilisateur)";
    $sqlLogbook = $sqlLogbook."VALUES ('$dates', 'Entree', '$comment', '$famille', $idProd, '$reference', '$designation', '$fournisseur',";
    $sqlLogbook = $sqlLogbook."$qte, $qty, $mini, '$emplacement', $pua, $pta, $puv, $ptv, 'User')";

    $bdd->query($sqlLogbook);

    $data = $dates."£".$reference."£".$designation."£".$qty."£Entree";
    $sqlTemp = "INSERT INTO t_temp (`Data`) VALUES ('$data')";
    $bdd->query($sqlTemp);
}

//////////////////////////////////////////////////////PRODUIT/////////////////////////////////////////////////


class CProduct{
    public $id;
    public $Famille;
    public $Reference;
    public $Designation;
    public $Fournisseur;
    public $Quantite;
    public $Mini;
    public $Emplacement;
    public $PUA;
    public $PTA;
    public $PUV;
    public $PTV;

    function set_id($id) { $this->id = $id; }
    function get_id() { return $this->id; }

    function set_famille($famille) { $this->Famille = $famille; }
    function get_famille() { return $this->Famille; }

    function set_reference($reference) { $this->Reference = $reference; }
    function get_reference() { return $this->Reference; }

    function set_designation($designation) { $this->Designation = $designation; }
    function get_designation() { return $this->Designation; }

    function set_fournisseur($fournisseur) { $this->Fournisseur = $fournisseur; }
    function get_fournisseur() { return $this->Fournisseur; }

    function set_quantite($quantite) { $this->Quantite = $quantite; }
    function get_quantite() { return $this->Quantite; }

    function set_mini($mini) { $this->Mini = $mini; }
    function get_mini() { return $this->Mini; }

    function set_emplacement($emplacement) { $this->Emplacement = $emplacement; }
    function get_emplacement() { return $this->Emplacement; }

    function set_pua($pua) { $this->PUA = $pua; }
    function get_pua() { return $this->PUA; }

    function set_pta($pta) { $this->PTA = $pta; }
    function get_pta() { return $this->PTA; }

    function set_puv($puv) { $this->PUV = $puv; }
    function get_puv() { return $this->PUV; }

    function set_ptv($ptv) { $this->PTV = $ptv; }
    function get_ptv() { return $this->PTV; }
}

?>