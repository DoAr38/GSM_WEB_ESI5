<?php

include('GSMLib.php');

if(isset($_POST['exportButton'])){
    exportoCsv();
}

function exportoCsv(){
    $bdd = Connection();

    $sql = "SELECT * FROM t_produits";

    $statement = $bdd->prepare($sql);

    $statement->execute();

    $rows = $statement->fetchAll();

    $fileName = "produits.csv";

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $fileName . '"');
    
    $fp = fopen('php://output', 'w');

    foreach ($rows as $row) {
        fputcsv($fp, $row);
    }
    //fclose($fp);
}


?>