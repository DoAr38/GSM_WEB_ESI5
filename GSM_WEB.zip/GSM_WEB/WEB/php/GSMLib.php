<?php

 // 15/03/21 - Développement de l'interface
 // 01/04/21 - Fin du développement de l'interface
 // 10/04/21 - Fin des corrections de l'interface
 // 20/04/21 - Développement fonctionnalité page des produits
 // 30/04/21 - Développement fonctionnalité page du journal
 // 09/05/21 - Développement fonctionnalité page des fournisseurs
 // 19/05/21 - Développement fonctionnalité page du graphique
 // 30/05/21 - Développement fonctionnalité entrée de produit
 // 12/06/21 - Développement fonctionnalité sortie de produit
 // 22/06/21 - Développement fonctionnalité export de produit et journal
 // 30/06/21 - Modifications suite aux retours client
 // 14/07/21 - Fin des corrections et tests
 // 30/07/21 - Mise en lien du site internet avec la blockchain locale

//Connexion à la base de données
function Connection(){
    try
    {
        $bdd = new PDO('mysql:host=217.182.207.237;dbname=GSM_WEB', 'Thomas','');
        $bdd->exec("SET CHARACTER SET utf8");
    }
    catch(Exception $e)
    {
        echo ($e->getMessage());
    }
    return $bdd;
}

//Graphique du nombre d'entrée / sortie sous forme de donut
function DonutChart(){
    $bdd = Connection();
    $res1 = "";
    $sql1 = "SELECT COUNT(*) as totalInput FROM t_journal WHERE `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql1) as $row1){
        $res1 = $row1['totalInput'];
    }
    $res2 = "";
    $sql2 = "SELECT COUNT(*) as totalOutput FROM t_journal WHERE `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql2) as $row2){
        $res2 = $row2['totalOutput'];
    }

    $dataDonutChart = $res1.",".$res2;
    return $dataDonutChart;
}

//Graphique du nombre d'entrée par mois sous forme de barre
function BarChartInput(){

    $bdd = Connection();

    $res1 = "";
    $sql1 = "SELECT COUNT(*) as as1 FROM `t_journal` WHERE Dates >= '2021-01-01' AND Dates <= '2021-02-01' AND `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql1) as $row1){
      $res1 = $row1['as1'];
    }
  
    $res2 = "";
    $sql2 = "SELECT COUNT(*) as as2 FROM `t_journal` WHERE Dates >= '2021-02-01' AND Dates <= '2021-03-01' AND `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql2) as $row2){
      $res2 = $row2['as2'];
    }

    $res3 = "";
    $sql3 = "SELECT COUNT(*) as as3 FROM `t_journal` WHERE Dates >= '2021-03-01' AND Dates <= '2021-04-01' AND `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql3) as $row3){
      $res3 = $row3['as3'];
    }

    $res4 = "";
    $sql4 = "SELECT COUNT(*) as as4 FROM `t_journal` WHERE Dates >= '2021-04-01' AND Dates <= '2021-05-01' AND `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql4) as $row4){
      $res4 = $row4['as4'];
    }
    
    $res5 = "";
    $sql5 = "SELECT COUNT(*) as as5 FROM `t_journal` WHERE Dates >= '2021-05-01' AND Dates <= '2021-06-01' AND `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql5) as $row5){
      $res5 = $row5['as5'];
    }

    $res6 = "";
    $sql6 = "SELECT COUNT(*) as as6 FROM `t_journal` WHERE Dates >= '2021-06-01' AND Dates <= '2021-07-01' AND `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql6) as $row6){
      $res6 = $row6['as6'];
    }

    $res7 = "";
    $sql7 = "SELECT COUNT(*) as as7 FROM `t_journal` WHERE Dates >= '2021-07-01' AND Dates <= '2021-08-01' AND `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql7) as $row7){
      $res7 = $row7['as7'];
    }

    $res8 = "";
    $sql8 = "SELECT COUNT(*) as as8 FROM `t_journal` WHERE Dates >= '2021-08-01' AND Dates <= '2021-09-01' AND `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql8) as $row8){
      $res8 = $row8['as8'];
    }

    $res9 = "";
    $sql9 = "SELECT COUNT(*) as as9 FROM `t_journal` WHERE Dates >= '2021-09-01' AND Dates <= '2021-10-01' AND `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql9) as $row9){
      $res9 = $row9['as9'];
    }

    $res10 = "";
    $sql10 = "SELECT COUNT(*) as as10 FROM `t_journal` WHERE Dates >= '2021-10-01' AND Dates <= '2021-11-01' AND `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql10) as $row10){
      $res10 = $row10['as10'];
    }

    $res11 = "";
    $sql11 = "SELECT COUNT(*) as as11 FROM `t_journal` WHERE Dates >= '2021-11-01' AND Dates <= '2021-12-01' AND `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql11) as $row11){
      $res11 = $row11['as11'];
    }

    $res12 = "";
    $sql12 = "SELECT COUNT(*) as as12 FROM `t_journal` WHERE Dates >= '2021-12-01' AND Dates <= '2022-01-01' AND `Type` LIKE '%Entr%'";
    foreach($bdd->query($sql12) as $row12){
      $res12 = $row12['as12'];
    }

    //Janvier, Fevrier, Mars, Avril, Mai, Juin, Juillet, Aout, Septembre, Octobre, Novembre, Decembre
    $dataBarChartInput = $res1.",".$res2.",".$res3.",".$res4.",".$res5.",".$res6.",".$res7.",".$res8.",".$res9.",".$res10.",".$res11.",".$res12;

    return $dataBarChartInput;
}

//Graphique du nombre de sortie par mois sous forme de barre
function BarChartOutput(){

    $bdd = Connection();

    $res1 = "";
    $sql1 = "SELECT COUNT(*) as as1 FROM `t_journal` WHERE Dates >= '2021-01-01' AND Dates <= '2021-02-01' AND `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql1) as $row1){
      $res1 = $row1['as1'];
    }
  
    $res2 = "";
    $sql2 = "SELECT COUNT(*) as as2 FROM `t_journal` WHERE Dates >= '2021-02-01' AND Dates <= '2021-03-01' AND `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql2) as $row2){
      $res2 = $row2['as2'];
    }

    $res3 = "";
    $sql3 = "SELECT COUNT(*) as as3 FROM `t_journal` WHERE Dates >= '2021-03-01' AND Dates <= '2021-04-01' AND `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql3) as $row3){
      $res3 = $row3['as3'];
    }

    $res4 = "";
    $sql4 = "SELECT COUNT(*) as as4 FROM `t_journal` WHERE Dates >= '2021-04-01' AND Dates <= '2021-05-01' AND `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql4) as $row4){
      $res4 = $row4['as4'];
    }
    
    $res5 = "";
    $sql5 = "SELECT COUNT(*) as as5 FROM `t_journal` WHERE Dates >= '2021-05-01' AND Dates <= '2021-06-01' AND `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql5) as $row5){
      $res5 = $row5['as5'];
    }

    $res6 = "";
    $sql6 = "SELECT COUNT(*) as as6 FROM `t_journal` WHERE Dates >= '2021-06-01' AND Dates <= '2021-07-01' AND `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql6) as $row6){
      $res6 = $row6['as6'];
    }

    $res7 = "";
    $sql7 = "SELECT COUNT(*) as as7 FROM `t_journal` WHERE Dates >= '2021-07-01' AND Dates <= '2021-08-01' AND `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql7) as $row7){
      $res7 = $row7['as7'];
    }

    $res8 = "";
    $sql8 = "SELECT COUNT(*) as as8 FROM `t_journal` WHERE Dates >= '2021-08-01' AND Dates <= '2021-09-01' AND `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql8) as $row8){
      $res8 = $row8['as8'];
    }

    $res9 = "";
    $sql9 = "SELECT COUNT(*) as as9 FROM `t_journal` WHERE Dates >= '2021-09-01' AND Dates <= '2021-10-01' AND `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql9) as $row9){
      $res9 = $row9['as9'];
    }

    $res10 = "";
    $sql10 = "SELECT COUNT(*) as as10 FROM `t_journal` WHERE Dates >= '2021-10-01' AND Dates <= '2021-11-01' AND `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql10) as $row10){
      $res10 = $row10['as10'];
    }

    $res11 = "";
    $sql11 = "SELECT COUNT(*) as as11 FROM `t_journal` WHERE Dates >= '2021-11-01' AND Dates <= '2021-12-01' AND `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql11) as $row11){
      $res11 = $row11['as11'];
    }

    $res12 = "";
    $sql12 = "SELECT COUNT(*) as as12 FROM `t_journal` WHERE Dates >= '2021-12-01' AND Dates <= '2022-01-01' AND `Type` LIKE '%Sort%'";
    foreach($bdd->query($sql12) as $row12){
      $res12 = $row12['as12'];
    }

    //Janvier, Fevrier, Mars, Avril, Mai, Juin, Juillet, Aout, Septembre, Octobre, Novembre, Decembre
    $dataBarChartOutput = $res1.",".$res2.",".$res3.",".$res4.",".$res5.",".$res6.",".$res7.",".$res8.",".$res9.",".$res10.",".$res11.",".$res12;

    return $dataBarChartOutput;
}


//Graphique du nombre de produits par famille
function DonutChart2(){
  $bdd = Connection();

  $res1 = "";
  $res2 = "";

  $famille = "";
  $sql1 = "SELECT DISTINCT Famille FROM t_produits";
  foreach($bdd->query($sql1) as $row1){
      $famille = $row1['Famille'];

      $sql2 = "SELECT COUNT(*) as totalProduct FROM t_produits WHERE Famille = '$famille'";
      

  }
}

?>