﻿using GsmLib;
using SoltiLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSM_WEB_BLOCKCHAIN
{
    public partial class Form1 : Form
    {
        static string m_XmlFileName = "GSM_WEB_BLOCKCHAIN.xml";
        string m_XmlEntete = "<block>";
        string m_XmlFooter = "</block>";
        string m_XmlHash_1 = "<hash>";
        string m_XmlHash_2 = "</hash>";
        string m_XmlPreviousHash_1 = "<previousHash>";
        string m_XmlPreviousHash_2 = "</previousHash>";
        string m_XmlData_1 = "<data>";
        string m_XmlData_2 = "</data>";
        string m_XmlDate_1 = "<date>";
        string m_XmlDate_2 = "</date>";

        LibGSM m_GSM = new LibGSM();
        LibGSM m_GSM_ACCESS = new LibGSM();
        static IBlock genesis = new Block("Genesis block", DateTime.Now.ToString());
        static byte[] difficulty = new byte[] { 0x00, 0x00 };

        BlockChain m_Chain;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            m_GSM.SetConnexionString("SERVER=217.182.207.237; DATABASE=GSM_WEB; UID=Thomas; PASSWORD=; PORT=3306;");
            m_GSM.Open();
            GetDataTemp();
            m_GSM.Close();
            labelBlockChain.Text = "Terminé";
        }

        void InitBlockChain()
        {
            labelStart.Text = "Démarrage en cours";
            m_GSM_ACCESS.Open();

            string sql = "SELECT ID FROM t_blockchain";
            List<object> lst = m_GSM_ACCESS.ExecuteReader(sql);

            if(lst.Count > 0)
            {
                foreach (object o in lst)
                {
                    CBlockchain b = getBlock(Tools.ConvToInt(o));
                    Block block = new Block(b.data, b.dates);
                    m_Chain.Add(block);
                }
            }

            m_GSM_ACCESS.Close();
            labelStart.Text = "Prêt";
        }

        void GetDataTemp()
        {
            listBoxConsult.Items.Add("\n");
            
            List<object> lstIdTemp = m_GSM.ExecuteReader("SELECT ID FROM t_temp");
            if(lstIdTemp != null && lstIdTemp.Count > 0)
            {
                foreach (object id in lstIdTemp)
                {
                    string sql = "SELECT Data FROM t_temp WHERE ID = " + id;
                    object value = m_GSM.GetValue(sql);
                    string[] token = value.ToString().Split('£');
                    string dates = token[0]; //dates

                    string data = value.ToString();
                    Block b = new Block(data, dates);
                    m_Chain.Add(b);

                    InsertDataInBDD(b);

                    listBoxContent.Items.Add("Transaction '" + id + "' ajoutée à la blockchain");

                    string sqlDelete = "DELETE FROM t_temp WHERE ID = " + id;
                    m_GSM.NonQuery(sqlDelete);
                }
            }

        }

        void InsertDataInBDD(Block b)
        {
            m_GSM_ACCESS.SetConnexionStringB(LibGSM.GetConnectionOledb4("GSM_WEB.mdb"));
            m_GSM_ACCESS.OpenB();

            string sql = "INSERT INTO t_blockchain (data, dates) VALUES ('" + b.Data + "','" + b.TimeStamp + "')";
            int err = m_GSM_ACCESS.NonQueryB(sql);

            m_GSM_ACCESS.CloseB();
        }

        public CBlockchain getBlock(int id)
        {
            CBlockchain block = new CBlockchain();

            string sql2 = "SELECT data FROM t_blockchain WHERE id = " + id;
            object value2 = m_GSM_ACCESS.GetValue(sql2);

            string sql3 = "SELECT dates FROM t_blockchain WHERE id = " + id;
            object value3 = m_GSM_ACCESS.GetValue(sql3);

            block.data = value2.ToString();
            block.dates = value3.ToString();

            return block;
        }

        private void buttonConsult_Click(object sender, EventArgs e)
        {
            listBoxConsult.Items.Clear();
            int cpt = 0;
            
            foreach(Block b in m_Chain)
            {
                if (b.Data.Contains("Genesis")) continue;
                string data = b.Data;
                string[] token = data.Split('£');
                string dateOfMouvement = token[0];
                string reference = token[1];
                string designation = token[2];
                string qte = token[3];
                string type = token[4];

                listBoxConsult.Items.Add("Previous Hash : " + BitConverter.ToString(b.PreviousHash).Replace("-", ""));
                listBoxConsult.Items.Add("Hash : " + BitConverter.ToString(b.Hash).Replace("-", ""));
                listBoxConsult.Items.Add("Données : ");
                listBoxConsult.Items.Add("Date du mouvement : " + dateOfMouvement);
                listBoxConsult.Items.Add("Reference : " + reference);
                listBoxConsult.Items.Add("Designation : " + designation);
                listBoxConsult.Items.Add("Quantite : " + qte);
                listBoxConsult.Items.Add("Type : " + type);

                listBoxConsult.Items.Add("");
                cpt++;
            }

            labelNbrTransac.Text = "Nombre de transactions : " + cpt;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            labelBlockChain.Text = "";
            m_GSM.SetConnexionString("SERVER=217.182.207.237; DATABASE=GSM_WEB; UID=Thomas; PASSWORD=; PORT=3306;");
            m_GSM_ACCESS.SetConnexionString(LibGSM.GetConnectionOledb4("GSM_WEB.mdb"));
            m_Chain = new BlockChain(difficulty, genesis);
            InitBlockChain();
        }

        private void buttonConsultInput_Click(object sender, EventArgs e)
        {
            listBoxConsult.Items.Clear();
            int cpt = 0;

            foreach (Block b in m_Chain)
            {
                if (b.Data.Contains("Genesis")) continue;
                if (b.Data.Contains("Sortie")) continue;
                string data = b.Data;
                string[] token = data.Split('£');
                string dateOfMouvement = token[0];
                string reference = token[1];
                string designation = token[2];
                string qte = token[3];
                string type = token[4];

                listBoxConsult.Items.Add("Previous Hash : " + BitConverter.ToString(b.PreviousHash).Replace("-", ""));
                listBoxConsult.Items.Add("Hash : " + BitConverter.ToString(b.Hash).Replace("-", ""));
                listBoxConsult.Items.Add("Données : ");
                listBoxConsult.Items.Add("Date du mouvement : " + dateOfMouvement);
                listBoxConsult.Items.Add("Reference : " + reference);
                listBoxConsult.Items.Add("Designation : " + designation);
                listBoxConsult.Items.Add("Quantite : " + qte);
                listBoxConsult.Items.Add("Type : " + type);

                listBoxConsult.Items.Add("");
                cpt++;
            }

            labelNbrTransac.Text = "Nombre de transactions : " + cpt;
        }

        private void buttonConsultOutput_Click(object sender, EventArgs e)
        {
            listBoxConsult.Items.Clear();
            int cpt = 0;

            foreach (Block b in m_Chain)
            {
                if (b.Data.Contains("Genesis")) continue;
                if (b.Data.Contains("Entree")) continue;
                string data = b.Data;
                string[] token = data.Split('£');
                string dateOfMouvement = token[0];
                string reference = token[1];
                string designation = token[2];
                string qte = token[3];
                string type = token[4];

                listBoxConsult.Items.Add("Previous Hash : " + BitConverter.ToString(b.PreviousHash).Replace("-", ""));
                listBoxConsult.Items.Add("Hash : " + BitConverter.ToString(b.Hash).Replace("-", ""));
                listBoxConsult.Items.Add("Données : ");
                listBoxConsult.Items.Add("Date du mouvement : " + dateOfMouvement);
                listBoxConsult.Items.Add("Reference : " + reference);
                listBoxConsult.Items.Add("Designation : " + designation);
                listBoxConsult.Items.Add("Quantite : " + qte);
                listBoxConsult.Items.Add("Type : " + type);

                listBoxConsult.Items.Add("");
                cpt++;
            }

            labelNbrTransac.Text = "Nombre de transactions : " + cpt;
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            listBoxConsult.Items.Clear();
            labelNbrTransac.Text = "Nombre de transactions : 0";
        }

        private void buttonQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    public static class BlockChainExtension
    {
        public static byte[] GenerateHash(this IBlock block)
        {
            using (SHA512 sha = new SHA512Managed())
            using (MemoryStream st = new MemoryStream())
            using (BinaryWriter bw = new BinaryWriter(st))
            {
                bw.Write(block.Data);
                bw.Write(block.Nonce);
                bw.Write(block.TimeStamp);
                bw.Write(block.PreviousHash);
                var starr = st.ToArray();
                return sha.ComputeHash(starr);
            }
        }
        public static byte[] MineHash(this IBlock block, byte[] difficulty)
        {
            if (difficulty == null) throw new ArgumentNullException(nameof(difficulty));
            byte[] hash = new byte[0];
            int d = difficulty.Length;
            while (!hash.Take(2).SequenceEqual(difficulty))
            {
                block.Nonce++;
                hash = block.GenerateHash();
            }
            return hash;
        }

        public static bool IsValid(this IBlock block)
        {
            var bk = block.GenerateHash();
            return block.Hash.SequenceEqual(bk);
        }

        public static bool IsValidPrevBlock(this IBlock block, IBlock prevBlock)
        {
            if (prevBlock == null) throw new ArgumentNullException(nameof(prevBlock));
            var prev = prevBlock.GenerateHash();
            return prevBlock.IsValid() && block.PreviousHash.SequenceEqual(prev);
        }
        public static bool IsValid(this IEnumerable<IBlock> items)
        {
            var enmerable = items.ToList();
            return enmerable.Zip(enmerable.Skip(1), Tuple.Create).All(block => block.Item2.IsValid() && block.Item2.IsValidPrevBlock(block.Item1));
        }
    }

    public interface IBlock
    {
        string Data { get; }
        byte[] Hash { get; set; }
        int Nonce { get; set; }
        byte[] PreviousHash { get; set; }
        string TimeStamp { get; }
    }

    public class Block : IBlock
    {
        public Block(string data, string dt)
        {
            Data = data ?? throw new ArgumentNullException(nameof(data));
            Nonce = 0;
            PreviousHash = new byte[] { 0x00 };
            TimeStamp = dt;
        }

        public Block() { }

        public string Data { get; }
        public byte[] Hash { get; set; }
        public int Nonce { get; set; }
        public byte[] PreviousHash { get; set; }
        public string TimeStamp { get; }

        public string DisplayHash() { return "Hash : " + BitConverter.ToString(Hash).Replace("-", ""); }
        public string DisplayPreviousHash() { return "Previous Hash : " + BitConverter.ToString(PreviousHash).Replace("-", ""); }
        public string DisplayData() { return "Données : " + Data; }
        public string DisplayDate() { return "Date : " + TimeStamp; }
        public string DisplaySeparator() { return "\n"; }

        public override string ToString()
        {
            string result = "Hash : " + BitConverter.ToString(Hash).Replace("-", "");
            result += "\r\n";
            result += "Previous Hash : " + BitConverter.ToString(PreviousHash).Replace("-", "");
            result += "\r\n";
            result += "Données : " + Data;
            result += "\r\n";
            result += "Date : " + TimeStamp;

            return result;
        }
    }

    public class BlockChain : IEnumerable<IBlock>
    {
        private List<IBlock> _items = new List<IBlock>();

        public BlockChain(byte[] difficulty, IBlock genesis)
        {
            Difficulty = difficulty;
            genesis.Hash = genesis.MineHash(difficulty);
            Items.Add(genesis);
        }

        public void Add(IBlock item)
        {
            if (Items.LastOrDefault() != null)
            {
                item.PreviousHash = Items.LastOrDefault()?.Hash;
            }
            item.Hash = item.MineHash(Difficulty);
            Items.Add(item);
        }

        public int Count => Items.Count;
        public IBlock this[int index]
        {
            get => Items[index];
            set => Items[index] = value;
        }
        public List<IBlock> Items
        {
            get => _items;
            set => _items = value;
        }

        public byte[] Difficulty { get; }

        public IEnumerator<IBlock> GetEnumerator()
        {
            return Items.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return Items.GetEnumerator();
        }
    }

    public class CBlockchain
    {
        public string data;
        public string dates;

        public CBlockchain() { }
    }
}