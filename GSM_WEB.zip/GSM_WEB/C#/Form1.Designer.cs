﻿
namespace GSM_WEB_BLOCKCHAIN
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listBoxContent = new System.Windows.Forms.ListBox();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonConsult = new System.Windows.Forms.Button();
            this.listBoxConsult = new System.Windows.Forms.ListBox();
            this.buttonConsultInput = new System.Windows.Forms.Button();
            this.buttonConsultOutput = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonQuit = new System.Windows.Forms.Button();
            this.labelStart = new System.Windows.Forms.Label();
            this.labelBlockChain = new System.Windows.Forms.Label();
            this.labelNbrTransac = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBoxContent
            // 
            this.listBoxContent.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxContent.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxContent.FormattingEnabled = true;
            this.listBoxContent.ItemHeight = 21;
            this.listBoxContent.Location = new System.Drawing.Point(38, 69);
            this.listBoxContent.Name = "listBoxContent";
            this.listBoxContent.Size = new System.Drawing.Size(1020, 235);
            this.listBoxContent.TabIndex = 0;
            // 
            // buttonStart
            // 
            this.buttonStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonStart.BackColor = System.Drawing.Color.DodgerBlue;
            this.buttonStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonStart.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStart.ForeColor = System.Drawing.Color.White;
            this.buttonStart.Location = new System.Drawing.Point(1105, 69);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(156, 65);
            this.buttonStart.TabIndex = 3;
            this.buttonStart.Text = "Mettre à jour la blockchain";
            this.buttonStart.UseVisualStyleBackColor = false;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonConsult
            // 
            this.buttonConsult.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonConsult.BackColor = System.Drawing.Color.DodgerBlue;
            this.buttonConsult.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonConsult.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.buttonConsult.ForeColor = System.Drawing.Color.White;
            this.buttonConsult.Location = new System.Drawing.Point(1105, 629);
            this.buttonConsult.Name = "buttonConsult";
            this.buttonConsult.Size = new System.Drawing.Size(156, 40);
            this.buttonConsult.TabIndex = 2;
            this.buttonConsult.Text = "Tout consulter";
            this.buttonConsult.UseVisualStyleBackColor = false;
            this.buttonConsult.Click += new System.EventHandler(this.buttonConsult_Click);
            // 
            // listBoxConsult
            // 
            this.listBoxConsult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxConsult.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxConsult.FormattingEnabled = true;
            this.listBoxConsult.ItemHeight = 17;
            this.listBoxConsult.Location = new System.Drawing.Point(38, 327);
            this.listBoxConsult.Name = "listBoxConsult";
            this.listBoxConsult.Size = new System.Drawing.Size(1020, 344);
            this.listBoxConsult.TabIndex = 1;
            // 
            // buttonConsultInput
            // 
            this.buttonConsultInput.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonConsultInput.BackColor = System.Drawing.Color.Green;
            this.buttonConsultInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonConsultInput.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonConsultInput.ForeColor = System.Drawing.Color.White;
            this.buttonConsultInput.Location = new System.Drawing.Point(1105, 461);
            this.buttonConsultInput.Name = "buttonConsultInput";
            this.buttonConsultInput.Size = new System.Drawing.Size(156, 40);
            this.buttonConsultInput.TabIndex = 4;
            this.buttonConsultInput.Text = "Entrée";
            this.buttonConsultInput.UseVisualStyleBackColor = false;
            this.buttonConsultInput.Click += new System.EventHandler(this.buttonConsultInput_Click);
            // 
            // buttonConsultOutput
            // 
            this.buttonConsultOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonConsultOutput.BackColor = System.Drawing.Color.Orange;
            this.buttonConsultOutput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonConsultOutput.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.buttonConsultOutput.ForeColor = System.Drawing.Color.White;
            this.buttonConsultOutput.Location = new System.Drawing.Point(1105, 507);
            this.buttonConsultOutput.Name = "buttonConsultOutput";
            this.buttonConsultOutput.Size = new System.Drawing.Size(156, 40);
            this.buttonConsultOutput.TabIndex = 5;
            this.buttonConsultOutput.Text = "Sortie";
            this.buttonConsultOutput.UseVisualStyleBackColor = false;
            this.buttonConsultOutput.Click += new System.EventHandler(this.buttonConsultOutput_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClear.BackColor = System.Drawing.Color.DodgerBlue;
            this.buttonClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClear.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClear.ForeColor = System.Drawing.Color.White;
            this.buttonClear.Location = new System.Drawing.Point(1105, 348);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(156, 40);
            this.buttonClear.TabIndex = 9;
            this.buttonClear.Text = "Effacer";
            this.buttonClear.UseVisualStyleBackColor = false;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonQuit
            // 
            this.buttonQuit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonQuit.BackColor = System.Drawing.Color.Red;
            this.buttonQuit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonQuit.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQuit.ForeColor = System.Drawing.Color.White;
            this.buttonQuit.Location = new System.Drawing.Point(1231, 12);
            this.buttonQuit.Name = "buttonQuit";
            this.buttonQuit.Size = new System.Drawing.Size(30, 40);
            this.buttonQuit.TabIndex = 10;
            this.buttonQuit.Text = "X";
            this.buttonQuit.UseVisualStyleBackColor = false;
            this.buttonQuit.Click += new System.EventHandler(this.buttonQuit_Click);
            // 
            // labelStart
            // 
            this.labelStart.AutoSize = true;
            this.labelStart.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStart.ForeColor = System.Drawing.Color.White;
            this.labelStart.Location = new System.Drawing.Point(34, 33);
            this.labelStart.Name = "labelStart";
            this.labelStart.Size = new System.Drawing.Size(81, 19);
            this.labelStart.TabIndex = 11;
            this.labelStart.Text = "labelStart";
            // 
            // labelBlockChain
            // 
            this.labelBlockChain.AutoSize = true;
            this.labelBlockChain.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBlockChain.ForeColor = System.Drawing.Color.White;
            this.labelBlockChain.Location = new System.Drawing.Point(1101, 152);
            this.labelBlockChain.Name = "labelBlockChain";
            this.labelBlockChain.Size = new System.Drawing.Size(138, 19);
            this.labelBlockChain.TabIndex = 12;
            this.labelBlockChain.Text = "labelBlockChain";
            // 
            // labelNbrTransac
            // 
            this.labelNbrTransac.AutoSize = true;
            this.labelNbrTransac.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNbrTransac.ForeColor = System.Drawing.Color.White;
            this.labelNbrTransac.Location = new System.Drawing.Point(830, 307);
            this.labelNbrTransac.Name = "labelNbrTransac";
            this.labelNbrTransac.Size = new System.Drawing.Size(201, 19);
            this.labelNbrTransac.TabIndex = 13;
            this.labelNbrTransac.Text = "Nombre de transactions :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1280, 720);
            this.Controls.Add(this.labelNbrTransac);
            this.Controls.Add(this.labelBlockChain);
            this.Controls.Add(this.labelStart);
            this.Controls.Add(this.buttonQuit);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonConsultOutput);
            this.Controls.Add(this.buttonConsultInput);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.listBoxContent);
            this.Controls.Add(this.buttonConsult);
            this.Controls.Add(this.listBoxConsult);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(1280, 720);
            this.MinimumSize = new System.Drawing.Size(1280, 720);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BlockChain GSM WEB";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxContent;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonConsult;
        private System.Windows.Forms.ListBox listBoxConsult;
        private System.Windows.Forms.Button buttonConsultInput;
        private System.Windows.Forms.Button buttonConsultOutput;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonQuit;
        private System.Windows.Forms.Label labelStart;
        private System.Windows.Forms.Label labelBlockChain;
        private System.Windows.Forms.Label labelNbrTransac;
    }
}

